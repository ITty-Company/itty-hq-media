# BRIEF — Haar! (Kapsalon Haar), Waalwijk · 19.11.2026
- Lead: web/kapsalon-haar-waalwijk · Grotestraat 393, 5142 CB Waalwijk · 0416 392 947 · facebook.com/kapsalonhaar
- Nu: kapsalonhaar.nl = één afbeelding «Welkom bij Kapsalon Haar» — geen tekst, geen tijden, geen diensten, geen mobiele versie. Fresha-vermelding (niet gekoppeld): tijden + «Hair Coloring».
- Feiten (Fresha): di 8:30–14:00, do 8:30–18:00, vr 8:30–18:00, za 8:30–14:00; ma/wo/zo gesloten. Dienst: kleuren. Geen prijzen, geen e-mail, geen Instagram, geen WhatsApp.
- Alles anders = voorbeeld / volgt van de salon. Geen reviews, geen prijzen, geen namen.
- Wat zeggen: «Uw site is nu één plaatje zonder telefoon of tijden; dit is een voorstel met online afspraak binnen uw openingstijden en een verhaal over kleuren.»
