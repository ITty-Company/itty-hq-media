# PALETTE — «Koper & Petrol»
spoelwit #F1F2EF (basis) · zink #DFE3E1 (vlakken) · petrol #0E3A3B (tekst/donkere banden) · koper #C2562A (accent, haarkleur) · perzik-toner #F3C2A6 (tweede accent) · muted #4F6564
Idee: de muur in de beelden is diep petrol, het haar wordt koper — de site neemt precies die twee over, licht en luchtig.
