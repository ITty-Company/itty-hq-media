# COPY — Barbershop Ferry (NL)
Rol: copywriter. Gegenereerd uit `_notes/build.py` (bron van waarheid). Alleen feiten uit BRIEF; geen prijzen, tijden, reviews of namen.

## Home — hero
**strak geknipt aan de Stationsstraat.**
Knippen, baard trimmen en scheren aan de Stationsstraat in Waalwijk. Plan je afspraak online, of bel even.

## Home — hoofdstukken over de film (regel · onderschrift · kaart)
- **even naar Ferry.** — Een gewone ochtend aan de Stationsstraat. De paal draait al.
  - *Een barbier aan de Stationsstraat*: Barbershop Ferry zit aan de Stationsstraat 130 in Waalwijk. Je herkent een barbier al van ver aan de paal naast de deur. Binnen draait het om één ding: dat je strak en verzorgd weer naar buiten loopt.
- **de paal draait.** — Rood, wit, blauw: al eeuwen het teken van de barbier.
  - *Het oudste uithangbord*: De rood-wit-blauwe paal hangt al eeuwen bij barbiers. Hij draait, zodat je hem ziet vanaf de overkant van de straat. Een beter teken bestaat eigenlijk niet: hier wordt geknipt en geschoren.
- **binnen is het rustig.** — Mint tegels, daglicht, een rode stoel.
  - *Even zitten*: Bij de barbier hoef je even niets. Jas uit, cape om, achterover in de stoel. Vertel wat je wilt — korter, een fade, alleen de baard — en de rest gebeurt vanzelf.
- **van nul tot acht.** — Opzetkam na opzetkam: zo ontstaat een fade.
  - *De fade, stap voor stap*: Een fade is een overgang: onderaan heel kort, naar boven toe steeds langer. Dat doe je met opzetkammen van klein naar groot, en met geduld. Elke stap moet vloeiend in de volgende overlopen — dan zie je geen lijn meer, alleen een verloop.
- **strak langs de lijn.** — Het mes van de tondeuse, scherp in het ochtendlicht.
  - *Lijnen die kloppen*: Een goede knipbeurt valt op aan de details: de nek, de lijn boven het oor, de overgang naar de baard. Daarvoor heb je scherp gereedschap nodig en een vaste hand.
- **warm voor het mes.** — Een warme handdoek maakt de huid zacht voor het scheren.
  - *Scheren zoals het hoort*: Voor een scheerbeurt wordt de huid eerst warm en zacht gemaakt, met een warme handdoek. Zo glijdt het mes makkelijker en heeft je huid er minder last van. Daarna: scheerschuim, een scherp mes, rustig werken.
- **een druppel voor de baard.** — Olie maakt een baard zacht — en hij ruikt goed.
  - *Verzorging voor je baard*: Na het trimmen of scheren hoort er verzorging bij. Een paar druppels baardolie maken het haar zacht en de huid eronder minder droog. Vraag gerust welke producten bij jouw baard passen.
- **en dan: jouw beurt.** — De stoel staat klaar. Kies een tijd die je uitkomt.
  - *Jouw stoel staat klaar*: Kies online een dienst en een tijd, of bel even — dan staat de stoel klaar als je binnenkomt.

## Diensten (Fresha)
- **Knippen** (Haircut) — Je haar weer in model: kort, een fade of gewoon netjes bijgewerkt. · prijs op aanvraag
- **Knippen & baard trimmen** (Haircut & Beard Trim) — Haar en baard in één keer, zodat alles weer bij elkaar past. · prijs op aanvraag
- **Baard trimmen** (Beard Trim) — Je baard op lengte en in vorm, met strakke lijnen. · prijs op aanvraag
- **Baard scheren** (Beard Shave) — Glad geschoren, met warme handdoek en een scherp mes. · prijs op aanvraag

### knippen.
Knippen bij de barbier begint met een korte vraag: hoe draag je je haar, wat moet eraf en wat mag blijven? Daarna gaat de tondeuse aan het werk, met opzetkammen van kort naar lang. Zo maak je een fade: onderaan bijna niets, naar boven toe steeds meer, zonder zichtbare lijn.
Bovenop komt de vorm met schaar en kam. Tot slot de details: de nek strak, de lijn rond het oor, even checken in de spiegel. Liever klassiek kort, een crop of alleen de punten? Zeg het gerust — dan wordt het precies zoals jij het draagt.

### knippen & baard trimmen.
Haar en baard horen bij elkaar. Als je je haar laat knippen maar de baard laat zitten, klopt de overgang vaak niet meer. Daarom kun je bij Ferry allebei in één afspraak laten doen: eerst het haar, dan de baard.
De baard wordt op lengte gebracht en in vorm getrimd, met strakke lijnen langs de wang en in de nek. De overgang van je bakkebaarden naar de baard loopt mooi in elkaar over. Zo loop je naar buiten als één geheel.

### baard trimmen.
Een baard groeit nooit helemaal gelijk. Op de ene plek sneller dan op de andere, en de lijnen vervagen na een paar weken. Bij het trimmen wordt je baard weer op lengte gebracht en in model gezet — vol waar het moet, kort waar het netter is.
Daarna de lijnen: langs de wangen, onder de kaak en in de nek. Een paar druppels baardolie maken het af: zacht haar en een huid die niet trekt. Welke producten Ferry gebruikt, hoor je in de zaak.

### baard scheren.
Glad scheren is een vak apart. Eerst gaat er een warme handdoek op je gezicht. Die maakt de huid en de haren zacht, zodat het mes makkelijker glijdt en je huid minder geïrriteerd raakt.
Daarna scheerschuim en een scherp mes, rustig en met de groeirichting mee. Tot slot iets verkoelends voor de huid. Het resultaat: glad, fris en verzorgd — en een kwartiertje waarin je even helemaal niets hoeft.

## Afspraak
plan je stoel. — 4 stappen: dienst → dag & tijd → gegevens → bevestigd. Demo: niets geboekt.

## Over ons
een barbier om de hoek. / meer dan een knipbeurt. / dit verhaal vertelt Ferry zelf (placeholder-vragen).

## Contact
Stationsstraat 130, 5141 GH Waalwijk · 06 28 71 89 27 · WhatsApp (nog te bevestigen) · Vaste tijden volgen.
