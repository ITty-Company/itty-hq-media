# PALETTE — «Paal & Tegel» (Barbershop Ferry)
Rol: palette-director. Licht dagwereld (SCROLL_FILM §0a). Kleuren uit de zaak zelf: de klassieke barberpaal (rood/wit/blauw), mint geglazuurde tegels, terrazzo werkblad.

| token | naam | hex | waar vandaan |
|---|---|---|---|
| --gold (accent) | **paalrood** | `#C42032` | de rode baan van de barberpaal, de kersenrode stoel |
| --sky (2e kleur) | **tegelmint** | `#A8D8C6` | mint geglazuurde tegels, terrazzo |
| --bordeaux (tekst/donker) | **inktblauw** | `#17233F` | de blauwe baan van de paal, tondeuse, scheermes-heft |
| --foam (basis) | **kalk** | `#F5F3EE` | kalkwitte gevel en muur |
| --marble (vlak) | **terrazzo** | `#E3ECE6` | mint-grijs werkblad |
| --muted | leisteen | `#4E5A72` | bijschriften |

Contrast (berekend, WCAG): inktblauw op kalk 14.0:1 · leisteen op kalk 6.3:1 · wit op paalrood 5.8:1 (knoppen: witte tekst) · inktblauw op tegelmint 9.9:1.
Alternatieven overwogen: (1) «Scheerzeep» — zeepblauw #8EC5E8 + citroen #F4D35E + navy; te dicht bij golden-fingers ochtendlucht. (2) «Stationsklok» — NS-geel #FFC917 + blauw; te veel NS-merk. Gekozen: Paal & Tegel.
Journal-check: geen hoofdkleur binnen ΔE≈10 van eerdere sites (warta-rood #F2382B is helderder/oranjer; kapsalon-haar petrol/koper; GF bordeaux/goud).
