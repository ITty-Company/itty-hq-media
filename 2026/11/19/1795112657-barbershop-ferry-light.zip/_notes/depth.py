#!/usr/bin/env python3
"""Depth maps for the keyframes (Depth-Anything-V2-Small, CPU) -> kf/depth/<k>.png (white = near). Used by seg.py for 2.5D parallax."""
import sys, os, numpy as np
from PIL import Image
from transformers import pipeline
KF = os.environ.get('KF', '/home/claude/bf/kf/raw/'); OUT = os.environ.get('DEPTH', '/home/claude/bf/kf/depth/')
pipe = pipeline('depth-estimation', model='depth-anything/Depth-Anything-V2-Small-hf', device='cpu')
for k in sys.argv[1:]:
    im = Image.open(KF + k + '.png').convert('RGB')
    d = np.asarray(pipe(im)['depth'].resize(im.size, Image.BICUBIC), np.float32)
    d = (d - np.percentile(d, 1)) / (np.percentile(d, 99) - np.percentile(d, 1) + 1e-6)
    Image.fromarray((np.clip(d, 0, 1) * 255).astype(np.uint8)).save(OUT + k + '.png'); print(k)
