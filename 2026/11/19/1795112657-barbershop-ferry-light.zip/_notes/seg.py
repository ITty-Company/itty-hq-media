#!/usr/bin/env python3
"""Barbershop Ferry — Mode B scroll film, round 2: ONE continuous camera, made in code from Higgsfield keyframes.
- every keyframe gets a depth map (_notes/depth.py, Depth-Anything-V2-Small) -> 2.5D parallax: near things grow/slide
  more than far things while the camera dollies or trucks;
- the camera never stops: holds are slow linear drifts, transitions continue that velocity (C1-continuous) and accelerate
  into a match point (pole stripe -> chair leather, guard row -> guard row, blue clipper -> blade, sunbeam -> window,
  steam -> mint haze, oil dish -> same dish, chair -> chair); the next shot decelerates out of the same kind of point;
- real motion blur: each transition frame averages several camera positions along the path.
usage: seg.py desktop|mobile|over|over-m|loops      env: KF (png keyframes), DEPTH (depth pngs), OUT (clips dir)"""
import numpy as np, subprocess, sys, os, json, math
from PIL import Image, ImageFilter
HERE = os.path.dirname(os.path.abspath(__file__))
KF = os.environ.get('KF', '/home/claude/bf/kf/raw/')
DEP = os.environ.get('DEPTH', '/home/claude/bf/kf/depth/')
OUTD = os.environ.get('OUT', '/home/claude/bf/clips/')
FPS = 24
IW, IH = 1344, 752
PD, PL = .3, .14          # parallax strength: dolly, lateral
DREF = .45                 # depth that stays put

def load(k):
    src = KF + k + '.png'
    if not os.path.exists(src): src = os.path.join(HERE, '..', 'assets', 'img', k + '.webp')
    im = np.asarray(Image.open(src).convert('RGB').resize((IW, IH), Image.LANCZOS), np.float32) / 255
    dp = DEP + k + '.png'
    # depth is blurred hard: smooth depth = objects stretch slightly instead of tearing/duplicating at their edges
    d = np.asarray(Image.open(dp).convert('L').resize((IW, IH), Image.BILINEAR).filter(ImageFilter.GaussianBlur(22)), np.float32) / 255 if os.path.exists(dp) else np.full((IH, IW), DREF, np.float32)
    return im, d

def ss(a, b, x): t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)

class R:
    def __init__(s, OW, OH, mobile):
        s.OW, s.OH, s.mob = OW, OH, mobile
        yy, xx = np.mgrid[0:OH, 0:OW].astype(np.float32)
        s.X, s.Y = (xx + .5) / OW - .5, (yy + .5) / OH - .5
        s.cw = (IH * OW / OH) / IW if mobile else 1.0
    def clampcam(s, c):
        sc, px, py = c; hw, hh = .5 * s.cw / sc, .5 / sc
        return (sc, min(max(px, hw), 1 - hw), min(max(py, hh), 1 - hh))
    def bil(s, img, u, v):
        u = np.clip(u * IW - .5, 0, IW - 1.001); v = np.clip(v * IH - .5, 0, IH - 1.001)
        x0 = u.astype(np.int32); y0 = v.astype(np.int32); fx = u - x0; fy = v - y0
        if img.ndim == 3: fx = fx[..., None]; fy = fy[..., None]
        return img[y0, x0] * (1 - fx) * (1 - fy) + img[y0, x0 + 1] * fx * (1 - fy) + img[y0 + 1, x0] * (1 - fx) * fy + img[y0 + 1, x0 + 1] * fx * fy
    def view(s, kd, cam, ref):
        """render keyframe (img, depth) with camera cam=(scale, px, py); parallax relative to the keyframe's rest camera ref"""
        img, dep = kd
        sc, px, py = s.clampcam(cam)
        u = px + s.X * s.cw / sc; v = py + s.Y / sc
        d = s.bil(dep, u, v) - DREF
        z = math.log(sc / ref[0])                       # dolly amount
        k = np.clip(1 + PD * z * d, .55, 1.8)
        lu = (px - ref[1]) * PL * d; lv = (py - ref[2]) * PL * d
        u2 = px + (u - px) / k + lu; v2 = py + (v - py) / k + lv
        return s.bil(img, u2, v2)

def lerpcam(a, b, t):
    return (math.exp(math.log(a[0]) + (math.log(b[0]) - math.log(a[0])) * t), a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)
def vec(a): return np.array([math.log(a[0]), a[1], a[2]])
def unvec(v): return (math.exp(v[0]), v[1], v[2])

def film(r, shots, trans, out, crf=16):
    """shots: list of dict(k, dur, c0, c1, [c0m, c1m]); trans: list (len shots-1) of dict(dur, a, b, m=(m0,m1), fx)"""
    mob = r.mob
    def cams(sh):
        return (sh.get('c0m', sh['c0']), sh.get('c1m', sh['c1'])) if mob else (sh['c0'], sh['c1'])
    data = {}
    for sh in shots:
        if sh['k'] not in data: data[sh['k']] = load(sh['k'])
    segs = []  # (t0, t1, kind, idx)
    t = 0
    for i, sh in enumerate(shots):
        segs.append((t, t + sh['dur'], 'h', i)); t += sh['dur']
        if i < len(trans): segs.append((t, t + trans[i]['dur'], 't', i)); t += trans[i]['dur']
    total = t; n = int(round(total * FPS))
    rests = []
    for a, b, kd, i in segs:
        if kd == 'h': rests.append((shots[i]['k'], round(a, 3), round(b, 3)))

    def camA(i, tt):  # leaving shot i: continue its velocity, accelerate into trans[i]['a'] — arriving there when the mix ends
        m1 = trans[i].get('m', (.42, .62))[1]; ta = min(tt / m1, 1.0)
        c0, c1 = cams(shots[i]); T = trans[i]['dur'] * m1; v0 = (vec(c1) - vec(c0)) / shots[i]['dur'] * T
        p0, p1 = vec(c1), vec(r.clampcam(trans[i]['a']))
        return unvec(p0 + v0 * ta + (p1 - p0 - v0) * ta ** 2.6)
    def camB(i, tt):  # entering shot i+1 from trans[i]['b'] (from the moment the mix starts), arriving with its hold velocity
        m0 = trans[i].get('m', (.42, .62))[0]; tb = max((tt - m0) / (1 - m0), 0.0)
        c0, c1 = cams(shots[i + 1]); T = trans[i]['dur'] * (1 - m0); v1 = (vec(c1) - vec(c0)) / shots[i + 1]['dur'] * T
        p0, p1 = vec(r.clampcam(trans[i]['b'])), vec(c0)
        return unvec(p1 - v1 * (1 - tb) - (p1 - v1 - p0) * (1 - tb) ** 2.6)
    def rend(kd, camf, tt, ref, blur):
        if blur <= 1: return r.view(kd, camf(tt), ref)
        acc = 0
        for j in range(blur):
            acc = acc + r.view(kd, camf(max(tt - .028 * j / (blur - 1), 0)), ref)
        return acc / blur
    def speed(camf, tt):
        a, b = vec(camf(max(tt - .02, 0))), vec(camf(min(tt + .02, 1)))
        return float(np.abs((b - a) * np.array([.6, 1, 1])).max()) / .04

    p = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{r.OW}x{r.OH}', '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-crf', str(crf), '-pix_fmt', 'yuv420p', out], stdin=subprocess.PIPE)
    for fi in range(n):
        tt = (fi + .5) / FPS
        a, b, kd, i = next(x for x in segs if x[0] <= tt < x[1]) if tt < total else segs[-1]
        e = min((tt - a) / (b - a), 1)
        if kd == 'h':
            sh = shots[i]; c0, c1 = cams(sh)
            f = r.view(data[sh['k']], lerpcam(c0, c1, e), c0)
        else:
            tr = trans[i]; A, B = shots[i], shots[i + 1]
            refA, refB = cams(A)[0], cams(B)[0]
            fa_cam = lambda q: camA(i, q); fb_cam = lambda q: camB(i, q)
            m0, m1 = tr.get('m', (.42, .62)); m = float(ss(m0, m1, e))
            ba = int(min(1 + speed(fa_cam, e) * 2.2, 9)); bb = int(min(1 + speed(fb_cam, e) * 2.2, 9))
            fa = rend(data[A['k']], fa_cam, e, refA, ba) if m < .999 else 0
            fb = rend(data[B['k']], fb_cam, e, refB, bb) if m > .001 else 0
            f = fa * (1 - m) + fb * m
            fx = tr.get('fx')
            bump = math.sin(math.pi * float(ss(m0 - .06, m1 + .06, e))) if fx else 0   # short: frames stay sharp until ~40% into the transition
            if fx == 'light':   # sunbeam blooms, exposure lifts, warm
                f = f + bump * .55 * (1 - f) * np.array([1, .95, .82], np.float32)
            elif fx == 'steam':  # soft white haze, slightly cool
                f = f * (1 - .6 * bump) + .6 * bump * np.array([.95, .97, .96], np.float32)
            elif fx == 'warm':
                f = f + bump * .18 * (1 - f) * np.array([1, .9, .75], np.float32)
        p.stdin.write((np.clip(f, 0, 1) * 255).astype(np.uint8).tobytes())
    p.stdin.close(); p.wait()
    return rests, total

# ------------------------------------------------------------------ the main film (cams: scale, centre-x, centre-y in image coords)
SHOTS = [
 dict(k='k1', dur=1.8, c0=(1.0, .5, .5), c1=(1.14, .43, .47), c0m=(1.0, .3, .5), c1m=(1.12, .29, .47)),
 dict(k='k2', dur=1.5, c0=(1.1, .46, .52), c1=(1.2, .53, .44)),
 dict(k='k7', dur=1.5, c0=(1.9, .5, .45), c1=(2.05, .53, .44)),   # ch.03: tight on headrest + leather (wide K7 only in the finale)
 dict(k='b1', dur=.7, c0=(1.14, .5, .5), c1=(1.2, .52, .55), c0m=(1.14, .4, .5), c1m=(1.2, .46, .55)),
 dict(k='k3', dur=1.6, c0=(1.1, .55, .55), c1=(1.16, .45, .56), c0m=(1.55, .5, .7), c1m=(1.6, .16, .7)),
 dict(k='k4', dur=1.5, c0=(1.08, .5, .55), c1=(1.18, .45, .6)),
 dict(k='k6', dur=1.5, c0=(1.06, .42, .5), c1=(1.16, .32, .46), c0m=(1.06, .26, .5), c1m=(1.14, .24, .46)),
 dict(k='k5', dur=1.5, c0=(1.14, .5, .5), c1=(1.05, .5, .5)),
 dict(k='b2', dur=1.0, c0=(1.0, .5, .5), c1=(1.1, .56, .46), c0m=(1.0, .5, .5), c1m=(1.1, .6, .46)),
 dict(k='k7', dur=1.8, c0=(1.04, .5, .52), c1=(1.12, .5, .5)),
]
TRANS = [
 dict(dur=1.6, a=(5.0, .27, .43), b=(2.1, .40, .46), m=(.46, .64)),                 # into the pole -> pole macro
 dict(dur=1.6, a=(4.2, .52, .2), b=(4.0, .5, .44), m=(.44, .6)),                    # red stripe -> red leather of the chair
 dict(dur=1.4, a=(1.5, .66, .55), b=(1.5, .36, .5), m=(.36, .64)),                  # truck right along the tiles to the counter
 dict(dur=1.5, a=(3.2, .55, .6), b=(2.6, .55, .7), m=(.44, .64)),                   # tilt down onto the guard row
 dict(dur=1.5, a=(3.6, .12, .72), b=(2.3, .42, .7), m=(.46, .64)),                  # blue clipper -> its blade
 dict(dur=1.6, a=(2.4, .3, .22), b=(2.0, .2, .28), m=(.46, .62), fx='light'),        # up into the sunbeam -> the window by the towel
 dict(dur=1.6, a=(3.0, .24, .26), b=(2.4, .5, .2), m=(.44, .62), fx='steam'),        # into the steam -> mint haze above the oil
 dict(dur=1.2, a=(1.0, .5, .5), b=(1.0, .5, .5), m=(.25, .75)),                    # same dish, the room opens behind it
 dict(dur=1.6, a=(2.7, .65, .32), b=(2.4, .5, .44), m=(.44, .62), fx='warm'),       # rack to the chair -> the chair
]
OVER_S = [dict(k='b1', dur=2.0, c0=(1.04, .5, .5), c1=(1.14, .6, .5), c0m=(1.04, .36, .5), c1m=(1.14, .5, .5)),
          dict(k='a1', dur=2.0, c0=(1.08, .62, .5), c1=(1.16, .72, .56), c0m=(1.08, .74, .5), c1m=(1.14, .74, .56))]
OVER_T = [dict(dur=1.6, a=(1.6, .72, .45), b=(1.5, .45, .5), m=(.36, .64), fx='light')]

if __name__ == '__main__':
    w = sys.argv[1]; os.makedirs(OUTD, exist_ok=True)
    if w == 'desktop': print(json.dumps(film(R(1280, 720, False), SHOTS, TRANS, OUTD + 'main.mp4')))
    if w == 'mobile': print(json.dumps(film(R(480, 768, True), SHOTS, TRANS, OUTD + 'main-m.mp4')))
    if w == 'over': print(json.dumps(film(R(1280, 720, False), OVER_S, OVER_T, OUTD + 'over.mp4')))
    if w == 'over-m': print(json.dumps(film(R(480, 768, True), OVER_S, OVER_T, OUTD + 'over-m.mp4')))
    if w == 'loops':
        for k, nm, c0, c1 in (('a1', 'loop-afspraak', (1.02, .5, .5), (1.1, .56, .52)), ('k7', 'loop-contact', (1.02, .5, .5), (1.1, .5, .48))):
            film(R(1280, 720, False), [dict(k=k, dur=6.0, c0=c0, c1=c1)], [], OUTD + nm + '.mp4')
