/* High Quality Nails (template: barbershop-ferry) — scroll film (chunked all-intra video scrub), D1 pan film, «lichtgordijn» portal,
   lacquer-bottle progress, «laklaag» page transition, lakwaaier, nu-open clock. No frameworks (Lenis only for inertia). */
(function () {
  'use strict';
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var mobile = matchMedia('(max-width:760px)').matches;
  var fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };
  var clamp = function (x, a, b) { return x < a ? a : x > b ? b : x; };
  var ease = function (x) { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
  var pad = function (n) { return ('0' + n).slice(-2); };
  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var WA_CONFIRMED = false; // zodra de salon WhatsApp bevestigt: true → label «nog te bevestigen» verdwijnt
  if (WA_CONFIRMED) $$('.wa-note').forEach(function (n) { n.remove(); });
  var root = document.documentElement;

  /* ---------- opening hours (Europe/Amsterdam): ma–vr 09:00–21:00, za/zo gesloten ---------- */
  function nlNow() {
    try {
      var p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Amsterdam', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date());
      var o = {}; p.forEach(function (x) { o[x.type] = x.value; });
      var wd = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[o.weekday];
      return { d: wd, h: +o.hour % 24, m: +o.minute };
    } catch (e) { var n = new Date(); return { d: n.getDay(), h: n.getHours(), m: n.getMinutes() }; }
  }
  function hoursState() {
    var n = nlNow(), mins = n.h * 60 + n.m, wk = n.d >= 1 && n.d <= 5;
    return { now: n, open: wk && mins >= 540 && mins < 1260 };
  }
  (function hours() {
    var s = hoursState();
    $$('[data-open]').forEach(function (c) { c.textContent = s.open ? 'nu open · tot 21:00' : 'nu gesloten · ma–vr 09:00–21:00'; c.classList.toggle('on', s.open); });
    $$('[data-nowline]').forEach(function (c) { c.textContent = s.open ? 'Nu open — tot 21:00' : 'Nu gesloten — ma–vr 09:00–21:00'; c.classList.toggle('on', s.open); });
    var di = (s.now.d + 6) % 7; /* monday = 0 */
    $$('.hours li').forEach(function (li, k) { li.classList.toggle('today', k === di); });
    $$('.dweek li').forEach(function (li, k) { li.classList.toggle('today', k === di); });
    $$('[data-dial]').forEach(function (d) {
      var hand = $('.hand', d), t = s.now.h + s.now.m / 60;
      hand.style.transform = 'rotate(' + (t / 24 * 360).toFixed(1) + 'deg)';
      $('[data-now]', d).textContent = pad(s.now.h) + ':' + pad(s.now.m);
      $('[data-state]', d).textContent = s.open ? 'nu open · tot 21:00' : 'nu gesloten';
    });
    setTimeout(hours, 30000);
  })();

  /* ---------- page transition «laklaag»: a cherry lacquer stroke runs down with the destination ---------- */
  var LBL = { 'index.html': 'home.', 'diensten.html': 'diensten.', 'afspraak.html': 'afspraak.', 'over-ons.html': 'over ons.', 'contact.html': 'contact.', '404.html': 'home.' };
  var lak = $('#lak');
  function fileOf(u) { var f = u.pathname.split('/').pop(); return f || 'index.html'; }
  if (lak) {
    var lblEl = $('.lbl', lak);
    if (window.__lk) lblEl.textContent = window.__lk;
    if (root.classList.contains('lk-closed')) {
      requestAnimationFrame(function () { requestAnimationFrame(function () {
        root.classList.remove('lk-noanim'); root.classList.add('lk-exit'); root.classList.remove('lk-closed');
      }); });
    }
    addEventListener('pageshow', function (e) { if (e.persisted) root.classList.remove('lk-closed', 'lk-noanim'); });
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0 || a.target || a.hasAttribute('download')) return;
      var u = new URL(a.href, location.href);
      if (u.origin !== location.origin || !/\.html$|\/$/.test(u.pathname)) return;
      var to = fileOf(u), from = fileOf(location);
      if (to === from && u.search === location.search) return;
      e.preventDefault();
      var lbl = LBL[to] || 'home.';
      lblEl.textContent = lbl;
      try { sessionStorage.setItem('lak', JSON.stringify({ l: lbl })); } catch (er) {}
      root.classList.add('lk-noanim'); root.classList.remove('lk-exit');
      requestAnimationFrame(function () {
        root.classList.remove('lk-noanim');
        requestAnimationFrame(function () { root.classList.add('lk-closed'); });
      });
      setTimeout(function () { location.href = u.href; }, reduce ? 220 : 780);
    });
  }

  /* ---------- header ---------- */
  var hd = $('.hd'), burger = $('.burger');
  if (burger) {
    burger.addEventListener('click', function () {
      var o = document.body.classList.toggle('menu-open'); burger.setAttribute('aria-expanded', o);
    });
    $$('.nav a').forEach(function (a) { a.addEventListener('click', function () { document.body.classList.remove('menu-open'); burger.setAttribute('aria-expanded', false); }); });
    addEventListener('keydown', function (e) { if (e.key === 'Escape') { document.body.classList.remove('menu-open'); burger.setAttribute('aria-expanded', false); } });
  }

  /* autoplay loops (afspraak / contact hero): poster on mobile, nothing with reduced motion */
  $$('video[data-auto]').forEach(function (v) {
    if (reduce || mobile) return;
    var go = function () {
      if (v.src) return;
      v.src = v.dataset.src; v.muted = true; v.loop = true;
      var p = v.play(); if (p && p.catch) p.catch(function () {});
    };
    var ob = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (e.isIntersecting) { go(); if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } }
        else if (v.src) v.pause();
      });
    }, { rootMargin: '200px' });
    ob.observe(v);
  });

  function loadBlob(url, onProgress) {
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('http ' + r.status);
      var total = +r.headers.get('content-length') || 0;
      if (!r.body || !total || !window.ReadableStream) return r.blob();
      var rd = r.body.getReader(), got = 0, parts = [];
      return (function pump() {
        return rd.read().then(function (x) {
          if (x.done) return new Blob(parts, { type: 'video/mp4' });
          parts.push(x.value); got += x.value.length; onProgress && onProgress(got / total);
          return pump();
        });
      })();
    }).then(function (b) { return URL.createObjectURL(b); });
  }

  /* glitter cursor trail (chapter «een vleugje glitter.»): pointer position in stage px */
  var ptr = { x: -1, y: -1, t: 0 };

  /* ---------- scroll films (video scrub) + pan film (D1) ---------- */
  var scrubs = $$('.film,.pan').map(function (film) {
    if (reduce) { film.classList.add('still'); return null; }
    var isPan = film.classList.contains('pan');
    var CH = JSON.parse($('script[type="application/json"]', film).textContent);
    if (mobile) CH.forEach(function (c) { if (c.gm) c.g = c.gm; });
    var N = CH.length, hero = $('.fhero,.phead', film);
    var rests = (hero ? [{ at: 0, ch: -1, c: .5, z: 1 }] : []).concat(CH.map(function (c, i) { return { at: c.at || 0, ch: i, c: c.c, z: mobile && c.zm ? c.zm : c.z }; }));
    var M = rests.length, HOLD = isPan ? .5 : .7;
    var stage = $('.stage', film), V = $('video', film), IMG = $('img.flat', film), cv = $('canvas.fx', film), ctx = cv.getContext('2d');
    var T = $('.ftitle', film), H2 = $('h2', T), S = $('p', T), cards = $$('.fcard', film);
    var hudT = $('.hud .hl', film), tcEl = $('.hud .tc', film), load = $('.hud .load s', film);
    var bot = $('.flesje', film), lakEl = bot && $('.lak', bot), ticks = bot ? $$('.ticks i', bot) : [], mbar = $('.mbar i', film);
    var hint = $('.fhint', film), fade = $('.fade', film), tag = $('.ftag', film), hud = $('.hud', film);
    var tag0 = tag && tag.textContent;
    /* keyframe still behind the chunks (critic P4): whatever the decoder does, the stage is never empty */
    var KFB = $('img.kfb', film), kfb0 = KFB && (mobile && KFB.dataset.m ? KFB.dataset.m : KFB.getAttribute('src'));
    if (KFB) KFB.src = kfb0;
    var VW = mobile ? 480 : 1280, VH = mobile ? 768 : 720, IW = 1344, IH = 752;
    var label = film.dataset.hud || '', total = +film.dataset.total || N, portalNext = film.hasAttribute('data-portal');
    var fallback = false, cur = -2, vt = 0, want = 0, pS = 0, words = [], ready = false, dur = +film.dataset.dur || 0;
    var FX = { mode: 'dust', k: 1, parts: [], t0: performance.now(), ch: 0, vis: 0 };
    if (fine) stage.addEventListener('mousemove', function (e) { var r = stage.getBoundingClientRect(); ptr.x = (e.clientX - r.left) * dpr; ptr.y = (e.clientY - r.top) * dpr; ptr.t = performance.now(); });

    /* chunked all-intra film: data-src="a.mp4|b.mp4|…" + data-seg="0,3,…" (chunk start times, s). Every chunk ≤ 2 MB. */
    var Vs = [], starts = [0], lens = [], act = 0, srcs = [];
    if (V) {
      srcs = (mobile ? film.dataset.srcM : film.dataset.src).split('|');
      var sg = mobile ? (film.dataset.segM || film.dataset.seg) : film.dataset.seg;
      if (sg) starts = sg.split(',').map(Number);
      if (mobile && film.dataset.posterM) V.poster = film.dataset.posterM;
      srcs.forEach(function (u, k) {
        var v = k ? V.cloneNode(false) : V;
        if (k) { v.removeAttribute('poster'); v.style.opacity = 0; V.parentNode.insertBefore(v, Vs[k - 1].nextSibling); }
        v.muted = true; v._ok = false;
        v.addEventListener('loadedmetadata', function () {
          v.pause(); v._ok = true; lens[k] = v.duration;
          if (!k) { ready = true; VW = v.videoWidth || VW; VH = v.videoHeight || VH; }
          if (!dur && k === srcs.length - 1) dur = starts[k] + v.duration;
        });
        v.addEventListener('seeked', function () { if (v._want === act) show(k); });
        Vs.push(v);
      });
    }
    function shownT() { var v = Vs[act]; if (!v) return want; return v && v._ok ? starts[act] + v.currentTime : want; }
    function show(k) { Vs.forEach(function (v, j) { v.style.opacity = j === k ? 1 : 0; }); }
    var started = false;
    function start() {
      if (started || !V) return; started = true;
      var n = srcs.length, done = [], cnt = 0;
      /* load the chunk that holds the current scroll time first, then the rest in order (critic P4) */
      function pick() {
        var c = 0; while (c < n - 1 && want >= starts[c + 1]) c++;
        if (!done[c]) return c;
        for (var j = 0; j < n; j++) if (!done[j]) return j;
        return -1;
      }
      (function next() {
        var k = pick();
        if (k < 0) { if (load) load.parentNode.style.opacity = 0; return; }
        done[k] = 1;
        loadBlob(srcs[k], function (q) { if (load) load.style.width = ((cnt + q) / n * 100) + '%'; })
          .then(function (u) { Vs[k].src = u; cnt++; next(); })
          .catch(function () { Vs[k].src = srcs[k]; cnt++; next(); });
      })();
    }
    if (V && film.getBoundingClientRect().top < innerHeight * 2.5) start();

    cards.concat(hero ? $$('.low', hero) : []).forEach(function (cd) {
      var m = $('.more', cd);
      if (m) m.addEventListener('click', function () { var x = cd.classList.toggle('x'); m.textContent = x ? 'minder −' : 'lees verder +'; m.setAttribute('aria-expanded', x); });
    });

    function setTitle(i) {
      if (i < 0) { H2.innerHTML = ''; S.textContent = ''; words = []; }
      else {
        var inEm = false;   /* keep <em> inside the word spans */
        H2.innerHTML = CH[i].t.split(' ').map(function (w) {
          var open = w.indexOf('<em>') >= 0, close = w.indexOf('</em>') >= 0; if (open) inEm = true;
          var clean = w.replace(/<\/?em>/g, ''), em = inEm; if (close) inEm = false;
          return '<span class="w' + (em ? ' em' : '') + '">' + clean + '</span>';
        }).join(' ');
        H2.setAttribute('aria-label', CH[i].t.replace(/<[^>]+>/g, ''));
        S.textContent = CH[i].s || '';
        words = $$('.w', H2);
        T.classList.remove('tl', 'tr', 'tc', 'mb'); T.classList.add(CH[i].pos || 'tl'); if (CH[i].mpos) T.classList.add(CH[i].mpos);
      }
      var j = Math.max(i, 0);
      if (hudT) hudT.textContent = label + ' · ' + pad(j + 1) + ' / ' + pad(total);
      if (tag && tag0) tag.textContent = j === 0 ? tag0 : 'Voorbeeldbeeld';
      if (KFB) { var want_src = i >= 1 && CH[i].img ? 'assets/img/' + CH[i].img + (mobile ? '-m' : '') + '.webp' : kfb0; if (KFB.getAttribute('src') !== want_src) KFB.src = want_src; }   /* «niet de echte gevel» only on the shopfront */
    }
    var seg = function (f) { return ease((f - .18) / .64); };
    function size() { cv.width = stage.clientWidth * dpr; cv.height = stage.clientHeight * dpr; }
    size(); addEventListener('resize', size);

    /* camera (video): a slow breathing scale on top of the rendered camera */
    var cam = { S: 1, ox: 0, oy: 0 };
    function cover() {
      var W = stage.clientWidth, Hh = stage.clientHeight, s0 = Math.max(W / VW, Hh / VH);
      var dw = VW * s0, dh = VH * s0;
      return { W: W, H: Hh, dw: dw, dh: dh, ox: (W - dw) / 2, oy: (Hh - dh) / 2 };
    }
    function toScreen(fx, fy) {
      if (isPan) return { x: fx * stage.clientWidth, y: fy * stage.clientHeight };
      var c = cover();
      var X = c.ox + fx * c.dw, Y = c.oy + fy * c.dh;
      return { x: cam.ox + (X - cam.ox) * cam.S, y: cam.oy + (Y - cam.oy) * cam.S };
    }
    function camera() {
      var c = cover();
      cam.S = 1.03 + .04 * Math.sin(Math.PI * pS); cam.ox = c.W / 2; cam.oy = c.H * (mobile ? .5 : .45);
      if (portalNext && pS > .97) cam.S = 1.03;
      var to = cam.ox.toFixed(1) + 'px ' + cam.oy.toFixed(1) + 'px', tf = 'scale(' + cam.S.toFixed(4) + ')';
      Vs.forEach(function (v) { v.style.transformOrigin = to; v.style.transform = tf; });
      if (KFB) { KFB.style.transformOrigin = to; KFB.style.transform = tf; }
    }
    /* pan camera over the flat-lay D1 */
    function panCam(i, e) {
      var W = stage.clientWidth, Hh = stage.clientHeight, s0 = Math.max(W / IW, Hh / IH);
      var a = rests[i], b = rests[Math.min(i + 1, M - 1)];
      var c = a.c + (b.c - a.c) * e, z = (a.z + (b.z - a.z) * e) * (1 - .08 * Math.sin(Math.PI * e));
      var s = s0 * z, DW = IW * s, DH = IH * s;
      var tx = clamp(W / 2 - c * DW, W - DW, 0), ty = clamp(Hh * (mobile ? .46 : .5) - .5 * DH, Hh - DH, 0);
      IMG.style.transform = 'translate3d(' + tx.toFixed(1) + 'px,' + ty.toFixed(1) + 'px,0) scale(' + s.toFixed(4) + ')';
    }

    function render() {
      var r = film.getBoundingClientRect(), tot = film.offsetHeight - innerHeight;
      if (r.bottom < -200 || r.top > innerHeight + 200) { if (r.top < innerHeight * 2.5) start(); return false; }
      start();
      var raw = clamp(-r.top / tot, 0, 1);
      pS += (raw - pS) * .18; if (Math.abs(raw - pS) < .0002) pS = raw;
      var u = Math.min(pS * (M - 1 + HOLD), M - 1), i = Math.min(Math.floor(u), M - 2), f = u - i;
      var e = seg(f);
      want = rests[i].at + (rests[i + 1].at - rests[i].at) * e;
      var near = f < .5 ? f : f - 1, nr = f < .5 ? i : i + 1, ch = rests[nr].ch;
      var vis = 1 - ease((Math.abs(near) - .3) / .16);  /* fully visible for ≥60% of each chapter, fades only at the edges */
      if (ch !== cur) { cur = ch; setTitle(ch); }
      var heroO = hero ? 1 - ease(u / .42) : 0;
      if (V) camera(); else panCam(i, e);
      if (hero) {
        hero.style.opacity = heroO; hero.style.translate = '0 ' + (-(1 - heroO) * 50) + 'px';
        hero.style.pointerEvents = heroO > .4 ? 'auto' : 'none'; hero.style.visibility = heroO < .01 ? 'hidden' : 'visible';
      }
      var endF = portalNext ? 1 - ease((pS - .94) / .055) : 1;
      var tv = (ch < 0 ? 0 : vis) * endF * (V && ready && !fallback && Math.abs(shownT() - want) > .45 ? 0 : 1);
      [hud, bot, tag].forEach(function (el) { if (el) el.style.opacity = endF; });
      var nW = words.length;
      words.forEach(function (sp, k) {
        var d = clamp((tv - k / Math.max(1, nW - 1) * .12) / .26, 0, 1);
        sp.style.opacity = d; sp.style.transform = 'translateY(' + ((1 - d) * .4).toFixed(3) + 'em)'; sp.style.filter = d > .99 ? 'none' : 'blur(' + ((1 - d) * 10).toFixed(1) + 'px)';
      });
      S.style.opacity = tv; T.style.setProperty('--sh', tv);
      cards.forEach(function (el, k) {
        var o = k === ch ? ease((tv - .05) / .35) : 0;
        el.style.opacity = o; el.style.transform = 'translateY(' + ((1 - o) * 24) + 'px)'; el.classList.toggle('on', o > .6);
      });
      /* lacquer bottle fills with the film; ticks light up per chapter */
      if (lakEl) lakEl.style.height = (pS * 100).toFixed(2) + '%';
      ticks.forEach(function (t, k) { t.classList.toggle('on', pS >= (k + .5) / ticks.length); });
      if (mbar) mbar.style.width = (pS * 100).toFixed(2) + '%';
      if (tcEl && dur) tcEl.textContent = '00:' + pad(Math.round(vt)) + ' / 00:' + pad(Math.round(dur));
      if (hint) hint.style.opacity = pS < .015 ? 1 : 0;
      if (fade) fade.style.opacity = ease((pS - .9) / .1);
      var cc = CH[Math.max(ch, 0)];
      FX.mode = cc.fx || 'dust'; FX.ch = Math.max(ch, 0); FX.k = .25 + .75 * (ch < 0 ? .6 : vis); FX.vis = ch < 0 ? 0 : vis;
      return true;
    }

    /* ---------- particles per chapter ---------- */
    function P(fx, fy) { var p = toScreen(fx, fy); return { x: p.x * dpr, y: p.y * dpr }; }
    var GLIT = ['255,255,255', '232,224,255', '205,189,242', '255,240,248'];
    function spawn() {
      var W = cv.width, Hh = cv.height, R = Math.random, m = FX.mode, c = CH[FX.ch];
      if (m === 'glitter') {   /* fine silver-lilac flakes drifting down through the upper half */
        return { x: W * (mobile ? .1 + R() * .8 : .3 + R() * .7), y: -10 * dpr, vx: (R() - .5) * .25, vy: .35 + R() * .7, r: (.8 + R() * 2.2) * dpr, c: GLIT[(R() * 4) | 0], life: 1, dec: .004 + R() * .004, star: R() < .35, ph: R() * 6.28 };
      }
      if (m === 'beam' && R() < .7) {   /* nail dust sparkling inside the diagonal sunbeam (upper left → middle) */
        var k = R(), a = mobile ? [.1, .05, .7, .55] : [.0, .05, .55, .7];
        return { x: W * (a[0] + (a[2] - a[0]) * k + (R() - .5) * .12), y: Hh * (a[1] + (a[3] - a[1]) * k + (R() - .5) * .1), vx: (R() - .3) * .2, vy: -(.05 + R() * .2), r: (.6 + R() * 1.6) * dpr, c: '255,252,246', a: .95, life: 0, up: 1, tw: 1, ph: R() * 6.28 };
      }
      if (m === 'led' && R() < .5) {    /* soft lilac light motes rising from the lamp */
        var q = P(.38 + R() * .24, .56 + R() * .1);
        return { x: q.x, y: q.y, vx: (R() - .5) * .2, vy: -(.2 + R() * .35), r: (1.2 + R() * 2.4) * dpr, c: '214,198,255', a: .8, life: 0, up: 1 };
      }
      var warm = c.warm;
      return { x: R() * W, y: R() * Hh * .85, vx: (R() - .3) * .22, vy: (R() - .5) * .18, r: (.7 + R() * 1.9) * dpr, c: warm ? (R() < .3 ? '246,190,150' : '255,232,214') : (R() < .15 ? '226,212,255' : (c.cool ? '240,244,255' : '255,250,246')), a: .85, life: 0, up: 1 };
    }
    function glint(sg, period, t) {
      var ph = ((t / 1000) % period) / period; if (ph > .22) return;
      var k = ph / .22, a = P(sg[0], sg[1]), b = P(sg[2], sg[3]);
      var x = a.x + (b.x - a.x) * k, y = a.y + (b.y - a.y) * k, s = (9 + 14 * Math.sin(Math.PI * k)) * dpr, al = Math.sin(Math.PI * k) * FX.vis;
      var g = ctx.createRadialGradient(x, y, 0, x, y, s * 2.2);
      g.addColorStop(0, 'rgba(255,248,252,' + .9 * al + ')'); g.addColorStop(1, 'rgba(255,220,236,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, s * 2.2, 0, 6.283); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,' + al + ')'; ctx.lineWidth = 1.2 * dpr;
      ctx.beginPath(); ctx.moveTo(x - s * 1.6, y); ctx.lineTo(x + s * 1.6, y); ctx.moveTo(x, y - s); ctx.lineTo(x, y + s); ctx.stroke();
    }
    function star(x, y, s, al, c) {
      ctx.strokeStyle = 'rgba(' + c + ',' + al + ')'; ctx.lineWidth = .9 * dpr;
      ctx.beginPath(); ctx.moveTo(x - s, y); ctx.lineTo(x + s, y); ctx.moveTo(x, y - s); ctx.lineTo(x, y + s); ctx.stroke();
    }
    function tick() {
      var t = performance.now() - FX.t0, now = performance.now();
      ctx.clearRect(0, 0, cv.width, cv.height);
      var m = FX.mode, nn = m === 'glitter' ? 3 : m === 'beam' ? 2 : 1;
      for (var k = 0; k < nn; k++) if (Math.random() < FX.k * (m === 'dust' ? .7 : 1)) FX.parts.push(spawn());
      if (m === 'glitter' && fine && FX.vis > .3 && now - ptr.t < 120 && ptr.x > 0) {
        for (var j = 0; j < 3; j++) FX.parts.push({ x: ptr.x + (Math.random() - .5) * 14 * dpr, y: ptr.y + (Math.random() - .5) * 14 * dpr, vx: (Math.random() - .5) * .6, vy: .2 + Math.random() * .8, r: (.8 + Math.random() * 2) * dpr, c: GLIT[(Math.random() * 4) | 0], life: 1, dec: .012, star: Math.random() < .5, ph: 0 });
      }
      FX.parts = FX.parts.filter(function (q) {
        q.x += q.vx; q.y += q.vy;
        if (q.up) { q.life += .008; if (q.life >= 1) q.up = 0; }
        else q.life -= q.dec || .004;
        if (q.life <= 0 && !q.up || q.y > cv.height + 30 || q.y < -80 * dpr) return false;
        var al = clamp(q.life, 0, 1);
        if (q.ph !== undefined && !q.tw) { q.x += Math.sin(t / 500 + q.ph) * .25; }
        if (q.star) { var tw = .5 + .5 * Math.sin(t / 120 + q.ph); star(q.x, q.y, q.r * (1.5 + 2 * tw), al * (.4 + .6 * tw), q.c); return true; }
        var a2 = al * (q.a || .9);
        if (q.tw) a2 *= .55 + .45 * Math.sin(t / 180 + q.ph);
        ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, 6.283);
        ctx.fillStyle = 'rgba(' + q.c + ',' + a2 + ')'; ctx.fill();
        return true;
      });
      if (FX.parts.length > 460) FX.parts.splice(0, FX.parts.length - 460);
      var c = CH[FX.ch];
      if (c.g && m === 'glint') glint(c.g, 5, t);
    }
    function seek() {
      if (!V || !ready) { vt = want; return; }
      var tgt = Math.min(want, (dur || want) - .05);
      vt = tgt;
      var k = 0; while (k < Vs.length - 1 && vt >= starts[k + 1]) k++;
      var v = Vs[k];
      /* chunk for this moment not loaded yet: hide the videos, the chapter's keyframe still (img.kfb) shows instead */
      if (!v._ok) { if (!fallback) { fallback = true; Vs.forEach(function (x) { x.style.opacity = 0; }); } return; }
      if (fallback) { fallback = false; act = -1; }
      var lt = Math.max(0, Math.min(vt - starts[k], (lens[k] || 99) - .03));
      if (k !== act) { act = k; v._want = k; }
      if (!v.seeking && Math.abs(v.currentTime - lt) > .001) { v._want = act; v.currentTime = lt; }
      else if (v.style.opacity !== '1' && !v.seeking) show(k);
    }
    setTitle(hero ? -1 : 0);
    if (!V) panCam(0, 0);
    return { render: render, tick: tick, seek: seek };
  }).filter(Boolean);

  /* ---------- portal «lichtgordijn»: the gloss on the finished tip swells into warm white light,
     then a vertical curtain of light opens on the shopfront at blue hour (K8) ---------- */
  var portals = $$('.portal').map(function (sec) {
    if (reduce) { sec.classList.add('still'); return null; }
    var stage = $('.pstage', sec), cv = $('canvas.gl', sec), txt = $('.ptext', sec), tag = $('.ptag', sec), dark = $('.pdark', sec), phud = $('.phud', sec);
    var A = mobile ? sec.dataset.aM : sec.dataset.a, B = mobile ? sec.dataset.bM : sec.dataset.b;
    var G = JSON.parse(mobile ? sec.dataset.gM : sec.dataset.g);
    var fbA = $('.pfb.a', sec), fbB = $('.pfb.b', sec);
    var gl = null, prog, U = {}, sizes = [[1, 1], [1, 1]], mx = 0, my = 0, smx = 0, smy = 0, t0 = performance.now();
    try { gl = cv.getContext('webgl', { antialias: false, premultipliedAlpha: false }); } catch (e) { gl = null; }
    if (fbA) fbA.src = A; if (fbB) fbB.src = B;
    if (gl) {
      var vs = 'attribute vec2 p;varying vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0.,1.);}';
      var fs = [
        'precision highp float;varying vec2 uv;uniform sampler2D A,B;uniform vec2 R,SA,SB,MO,G,O;uniform float P,T,KB,Z;',
        'vec2 cov(vec2 u,vec2 s,float z,vec2 o){float ra=R.x/R.y,ia=s.x/s.y;vec2 sc=ra>ia?vec2(1.,ia/ra):vec2(ra/ia,1.);vec2 q=o+(u-o)/z;return (q-.5)*sc+.5;}',
        'void main(){float asp=R.x/R.y;',
        'vec3 a=texture2D(A,cov(uv,SA,Z*(1.+.06*P),O)).rgb;',
        'vec2 g=vec2(G.x,1.-G.y);vec2 d=(uv-g)*vec2(asp,1.);float dist=length(d);float an=atan(d.y,d.x);',
        'float k=smoothstep(0.,.6,P);',
        'float rays=pow(abs(sin(an*5.+T*.2)),18.)*.6+pow(abs(sin(an*9.-T*.3)),30.)*.45;',
        'float glow=exp(-dist*dist/(.0012+k*k*.5));float halo=exp(-dist*dist/(.02+k*k*1.5));',
        'vec3 LAK=vec3(.78,.09,.36),HOT=vec3(1.,.975,.95),LIL=vec3(.80,.74,.95);',
        'vec3 col=a+HOT*glow*(.2+.45*k)+LAK*halo*k*.16+HOT*rays*halo*k*.22;',
        'float fill=smoothstep(.28,.58,P);col=mix(col,HOT,fill*.86);',
        /* the curtain: a vertical band of light opening from the glint, with soft folds */
        'float dx=abs(uv.x-g.x)*asp;float folds=.018*sin(uv.y*23.+T*1.1)+.012*sin(uv.y*41.-T*.8)+.01*sin(uv.x*60.);',
        'float Rr=mix(-.06,asp*1.1+.1,smoothstep(.34,.96,P));float mb=smoothstep(Rr,Rr-.06,dx+folds);',
        'vec3 b=texture2D(B,cov(uv,SB,KB,vec2(.5))+MO*.008).rgb;',
        'float rim=smoothstep(Rr-.14,Rr-.01,dx+folds)*mb*(1.-smoothstep(.94,1.,P));',
        'float streak=(pow(abs(sin(uv.x*11.+T*.25)),8.)*.08+pow(abs(sin(uv.x*23.-T*.4)),12.)*.05)*(1.-mb)*fill*smoothstep(1.,.75,P);',
        'vec3 b2=mix(HOT,b,smoothstep(.5,.94,P));col=mix(col,b2,mb);col=mix(col,mix(HOT,LIL,.25),rim*.55);col+=streak;gl_FragColor=vec4(clamp(col,0.,1.),1.);}'
      ].join('\n');
      var sh = function (t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
      try {
        prog = gl.createProgram(); gl.attachShader(prog, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(prog); gl.useProgram(prog);
        var bf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, bf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
        var lp = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(lp); gl.vertexAttribPointer(lp, 2, gl.FLOAT, false, 0, 0);
        ['A', 'B', 'R', 'SA', 'SB', 'MO', 'G', 'O', 'P', 'T', 'KB', 'Z'].forEach(function (k) { U[k] = gl.getUniformLocation(prog, k); });
        [A, B].forEach(function (url, i) {
          var tx = gl.createTexture();
          gl.activeTexture(gl.TEXTURE0 + i); gl.bindTexture(gl.TEXTURE_2D, tx);
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([236, 232, 245, 255]));
          ['TEXTURE_WRAP_S', 'TEXTURE_WRAP_T'].forEach(function (w) { gl.texParameteri(gl.TEXTURE_2D, gl[w], gl.CLAMP_TO_EDGE); });
          gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
          var im = new Image(); im.onload = function () {
            gl.activeTexture(gl.TEXTURE0 + i); gl.bindTexture(gl.TEXTURE_2D, tx); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im); sizes[i] = [im.naturalWidth, im.naturalHeight];
          }; im.src = url;
        });
        gl.uniform1i(U.A, 0); gl.uniform1i(U.B, 1);
        sec.classList.add('gl');
      } catch (e) { gl = null; }
    }
    function size() { var k = Math.min(dpr, 1.5); cv.width = stage.clientWidth * k; cv.height = stage.clientHeight * k; if (gl) gl.viewport(0, 0, cv.width, cv.height); }
    size(); addEventListener('resize', size);
    if (fine) addEventListener('mousemove', function (e) { mx = e.clientX / innerWidth * 2 - 1; my = -(e.clientY / innerHeight * 2 - 1); });
    var sm = 0;
    return function () {
      var r = sec.getBoundingClientRect(), tot = sec.offsetHeight - innerHeight;
      sec.classList.toggle('live', r.top <= 1);
      if (r.bottom < 0 || r.top > 1) return;
      var raw = clamp(-r.top / tot, 0, 1); sm += (raw - sm) * .2;
      var Pp = clamp(sm / .4, 0, 1), q = sm;
      var kb = 1 + .06 * ease((q - .4) / .6);
      smx += (mx - smx) * .05; smy += (my - smy) * .05;
      if (gl) {
        gl.uniform2f(U.R, cv.width, cv.height); gl.uniform2f(U.SA, sizes[0][0], sizes[0][1]); gl.uniform2f(U.SB, sizes[1][0], sizes[1][1]);
        gl.uniform2f(U.MO, smx, smy); gl.uniform2f(U.G, G[0], G[1]); gl.uniform2f(U.O, .5, mobile ? .5 : .55);
        gl.uniform1f(U.P, Pp); gl.uniform1f(U.T, (performance.now() - t0) / 1000); gl.uniform1f(U.KB, kb); gl.uniform1f(U.Z, 1.03);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      } else if (fbB) {
        fbB.style.setProperty('--r', (ease((Pp - .3) / .7) * 100) + '%');
        fbB.style.transform = 'scale(' + kb + ')';
      }
      stage.style.setProperty('--dust', ease((Pp - .6) / .3));
      var o = ease((q - .36) / .1) * (1 - ease((q - .975) / .025));
      txt.style.opacity = o; txt.style.translate = '0 ' + ((1 - o) * 40) + 'px'; txt.style.pointerEvents = o > .5 ? 'auto' : 'none';
      if (tag) tag.style.opacity = ease((Pp - .9) / .1) * (1 - ease((q - .9) / .06));
      if (phud) phud.style.opacity = ease((Pp - .9) / .1) * (1 - ease((q - .9) / .06));
      if (dark) dark.style.opacity = ease((q - .95) / .05);
    };
  }).filter(Boolean);

  /* ---------- reveals ---------- */
  $$('.words').forEach(function (el) {
    var i = 0;
    el.innerHTML = el.innerHTML.trim().split(/\s+/).map(function (w) { return '<span class="wd" style="--i:' + (i++) + '">' + w + '</span>'; }).join(' ');
  });
  $$('.fill p').forEach(function (p) {
    p.innerHTML = p.textContent.trim().split(/\s+/).map(function (w) { return '<span class="wd">' + w + '</span>'; }).join(' ');
  });
  var io = new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: .12 });
  $$('.rv,.words').forEach(function (el) { io.observe(el); });

  if (fine) $$('.glow-follow').forEach(function (el) {
    el.addEventListener('mousemove', function (e) {
      var r = el.getBoundingClientRect(); el.style.setProperty('--mx', (e.clientX - r.left) + 'px'); el.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
  });

  /* ---------- lakwaaier: tap a swatch, the SVG tip gets that lacquer ---------- */
  $$('.waaier').forEach(function (w) {
    var stg = $('.nailstage', w), stops = $$('#lk stop', stg), out = $('[data-pick]', w);
    $$('.swatch', w).forEach(function (s) {
      s.addEventListener('click', function () {
        $$('.swatch', w).forEach(function (x) { x.setAttribute('aria-pressed', x === s); });
        var c = s.dataset.c, c2 = s.dataset.c2;
        if (stops.length === 4) { stops[0].setAttribute('stop-color', c2); stops[1].setAttribute('stop-color', c); stops[2].setAttribute('stop-color', c); stops[3].setAttribute('stop-color', c2); }
        if (out) out.textContent = s.dataset.n;
        if (!reduce && stg.animate) stg.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.03)' }, { transform: 'scale(1)' }], { duration: 500, easing: 'cubic-bezier(.2,.7,.2,1)' });
      });
    });
  });

  /* ---------- ambient canvases: dust in light (warm/gold), glints ---------- */
  var ambient = $$('canvas.dust,canvas.glints').map(function (cv) {
    var ctx = cv.getContext('2d'), parts = [], kind = cv.dataset.k || 'warm', gl = cv.classList.contains('glints');
    function size() { cv.width = cv.clientWidth * dpr; cv.height = cv.clientHeight * dpr; }
    size(); addEventListener('resize', size);
    var host = cv.closest('.pstage');
    return function () {
      var r = cv.getBoundingClientRect(); if (r.bottom < 0 || r.top > innerHeight || !cv.width) return;
      var lvl = host ? +(getComputedStyle(host).getPropertyValue('--dust') || 0) : 1;
      var W = cv.width, H = cv.height, R = Math.random;
      if (R() < (gl ? .25 : .5) * Math.max(lvl, .05)) parts.push(gl
        ? { x: W * (.05 + R() * .5), y: H * (.1 + R() * .7), vx: 0, vy: -.1, r: (2 + R() * 4) * dpr, life: 1, dec: .016, star: 1 }
        : { x: W * (.05 + R() * .9), y: R() * H, vx: -(.03 + R() * .16), vy: (R() - .6) * .2, r: (.7 + R() * 2) * dpr, life: 0, up: 1, gold: R() < (kind === 'gold' ? .55 : .2) });
      ctx.clearRect(0, 0, W, H);
      ctx.globalAlpha = host ? lvl : 1;
      parts = parts.filter(function (q) {
        q.x += q.vx; q.y += q.vy;
        if (q.up) { q.life += .006; if (q.life >= 1) q.up = 0; } else q.life -= q.dec || .004;
        if (q.life <= 0 && !q.up) return false;
        if (q.star) {
          var s = q.r * Math.sin(q.life * Math.PI);
          ctx.strokeStyle = 'rgba(255,255,255,' + q.life + ')'; ctx.lineWidth = dpr;
          ctx.beginPath(); ctx.moveTo(q.x - s, q.y); ctx.lineTo(q.x + s, q.y); ctx.moveTo(q.x, q.y - s); ctx.lineTo(q.x, q.y + s); ctx.stroke();
          return true;
        }
        ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, 6.283);
        var base = kind === 'gold' ? '240,141,180' : '255,236,214';
        ctx.fillStyle = 'rgba(' + (q.gold ? '205,189,242' : base) + ',' + (.8 * q.life) + ')'; ctx.fill();
        return true;
      });
      ctx.globalAlpha = 1;
      if (parts.length > 240) parts.splice(0, parts.length - 240);
    };
  });

  /* ---------- scroll-linked extras ---------- */
  var par = $$('[data-par]'), marq = $$('.marq div'), fills = $$('.fill'), kb = $$('[data-kb]');
  var lmx = 0, lmy = 0;
  if (fine) addEventListener('mousemove', function (e) { lmx = e.clientX / innerWidth - .5; lmy = e.clientY / innerHeight - .5; });
  function extras() {
    var vh = innerHeight;
    if (hd) hd.classList.toggle('solid', scrollY > 40);
    if (reduce) return;
    par.forEach(function (el) {
      var r = el.parentNode.getBoundingClientRect(); if (r.bottom < 0 || r.top > vh) return;
      var k = (r.top + r.height / 2 - vh / 2) / vh;
      el.style.transform = 'translate3d(0,' + (k * -(+el.dataset.par || 50)) + 'px,0) scale(1.12)';
    });
    kb.forEach(function (el) {
      var r = el.parentNode.getBoundingClientRect(); if (r.bottom < 0 || r.top > vh) return;
      var k = clamp(1 - r.bottom / (vh + r.height), 0, 1);
      el.style.transform = 'translate3d(' + (lmx * -16) + 'px,' + (lmy * -10 + (k - .5) * -36) + 'px,0) scale(' + (1.05 + k * .05) + ')';
    });
    marq.forEach(function (el, i) { el.style.transform = 'translate3d(' + (-(scrollY * .25) % (el.scrollWidth / 2)) * (i % 2 ? -1 : 1) + 'px,0,0)'; });
    fills.forEach(function (el) {
      var r = el.getBoundingClientRect(); if (r.bottom < 0 || r.top > vh) return;
      var sp = $$('.wd', el), k = clamp((vh * .92 - r.top) / (r.height * .8 + vh * .1), 0, 1) * sp.length;
      sp.forEach(function (s, i) { s.classList.toggle('lit', i < k); });
    });
  }
  if (reduce) $$('.fill .wd').forEach(function (s) { s.classList.add('lit'); });

  /* ---------- loop ---------- */
  var lenis = (window.Lenis && !reduce) ? new Lenis({ lerp: .1 }) : null;
  window.__lenis = lenis;
  (function raf(t) {
    if (lenis) lenis.raf(t);
    scrubs.forEach(function (f) { if (f.render()) { f.seek(); f.tick(); } });
    portals.forEach(function (p) { p(); });
    if (!reduce) ambient.forEach(function (a) { a(); });
    extras();
    requestAnimationFrame(raf);
  })(0);
})();
